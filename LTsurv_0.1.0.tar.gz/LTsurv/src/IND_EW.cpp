#include <Rcpp.h>
#include <RcppEigen.h>
#include <iostream>

// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;

using Eigen::Map;
using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;


//[[Rcpp::export]]
Eigen::MatrixXd RLInd(Eigen::MatrixXd X,
                      Eigen::ArrayXd W,
                      Eigen::ArrayXd DL){
  const int n(X.rows()), m(W.size());
  Eigen::MatrixXd out(n,m);

  for(int i = 0; i < n; ++i) {
    out.row(i) = (W >= X(i, 2) and W <= X(i, 3)).cast<double>().matrix()*DL(i);
  }
  return out;
}

//[[Rcpp::export]]
Eigen::MatrixXd RAInd(Eigen::MatrixXd X,
                      Eigen::ArrayXd W){
  const int n(X.rows()), m(W.size());
  Eigen::MatrixXd out(n,m);

  for(int i = 0; i < n; ++i) {
    out.row(i) = (W >= X(i, 1) and W <= X(i, 3)).cast<double>().matrix();
  }
  return out;
}

// [[Rcpp::export]]
Eigen::MatrixXd AInd(Eigen::MatrixXd X,
                     Eigen::ArrayXd W){
  const int n(X.rows()), m(W.size());
  Eigen::MatrixXd out(n,m);
  for(int i = 0; i < n; ++i) {
    out.row(i) = (W <= X(i, 1)).cast<double>().matrix();
  }
  return out;
}

// [[Rcpp::export]]
Eigen::MatrixXd DInd(Eigen::MatrixXd X,
                     Eigen::ArrayXd W){
  const int n(X.rows()), m(W.size());
  Eigen::MatrixXd  out(n,m);

  for(int i = 0; i < n; ++i) {
    out.row(i) = (W == X(i, 0)).cast<double>().matrix();
  }
  return out;
}

//[[Rcpp::export]]
Eigen::MatrixXd EWfun(Eigen::MatrixXd Z,
                      Eigen::MatrixXd IndD,
                      Eigen::MatrixXd IndRL,
                      Eigen::VectorXd b,
                      Eigen::VectorXd h){
  const int n(Z.rows()), m(h.size());
  double bot;
  Eigen::VectorXd ebz(n);
  Eigen::MatrixXd EW(n,m);

  ebz = (Z * b).array().exp();
  for(int i = 0; i < n; ++i){
    EW.row(i) = (IndRL.row(i)).adjoint().array()*h.array()*ebz(i) ;
    bot = 1-exp(-h.dot(IndRL.row(i))*ebz(i));
    if(bot==0.0){bot=1.0;}
    EW.row(i) = EW.row(i)/bot+IndD.row(i);
  }
  return EW;
}

//[[Rcpp::export]]
Eigen::VectorXd Lambda(Eigen::MatrixXd Z,
                       Eigen::MatrixXd EW,
                       Eigen::MatrixXd IndA,
                       Eigen::MatrixXd IndRA,
                       Eigen::VectorXd b,
                       Eigen::VectorXd h){
  const int n(Z.rows()), m(h.size());
  double Rij;
  Eigen::VectorXd UC_Lambda1(m),UC_Lambda2(m),UP_Lambda(m), Ind2ij(m), ebz(n);
  UC_Lambda1.fill(0);UC_Lambda2.fill(0);UP_Lambda.fill(0);

  ebz = (Z * b).array().exp();
  UC_Lambda1 = (IndRA.cwiseProduct(EW)).colwise().sum();
  for(int i = 0; i < n; ++i){
    UC_Lambda2 += ebz(i) * IndRA.row(i);
    for(int j = i+1; j < n; ++j){
      Ind2ij = IndA.row(i) - IndA.row(j);
      Rij = exp((ebz(i) - ebz(j)) * h.dot(Ind2ij));
      UP_Lambda += (ebz(i) - ebz(j)) / (1 + 1 / Rij) * Ind2ij;
    }
  }
  return (UC_Lambda1/n).array()/(UC_Lambda2 / n + 2.0*UP_Lambda / n / (n - 1)).array();
}

//[[Rcpp::export]]
Eigen::MatrixXd Beta(Eigen::MatrixXd Z,
                     Eigen::MatrixXd EW,
                     Eigen::MatrixXd IndA,
                     Eigen::MatrixXd IndRA,
                     Eigen::VectorXd b,
                     Eigen::VectorXd h){
  const int n(Z.rows()),p(b.size());
  double H_diff, Rij;
  Eigen::VectorXd UC_b(p), UP_b(p), ebz(n), Q1ij(p);
  UC_b.fill(0); UP_b.fill(0);
  Eigen::MatrixXd JC_b(p,p), JP_b(p,p), zebz(p,n);
  JC_b.fill(0); JP_b.fill(0);

  ebz = (Z*b).array().exp();
  zebz= ebz.adjoint().replicate(p,1).array()*Z.adjoint().array();
  for(int i=0; i<n; i++){
    UC_b += ((IndRA.row(i)).dot(EW.row(i)) - h.dot(IndRA.row(i))*ebz(i)) *Z.row(i);
    JC_b += h.dot(IndRA.row(i))*ebz(i)*(Z.row(i).adjoint()*Z.row(i));
    for(int j=i+1; j<n; j++){
      H_diff = h.dot(IndA.row(i) - IndA.row(j));
      Rij = exp((ebz(i) - ebz(j)) * H_diff);
      Q1ij = (zebz.col(i) - zebz.col(j)) * H_diff;
      UP_b += -(Rij * Q1ij) / (1 + Rij);
      JP_b += Rij / pow(1 + Rij, 2) * Q1ij * Q1ij.adjoint() +
        Rij / (1 + Rij) * H_diff *
        (Z.row(i).adjoint() * Z.row(i)* ebz(i) -
        Z.row(j).adjoint() * Z.row(j)* ebz(j));
    }
  }
  return   (JC_b/n+2.0*JP_b/n/(n-1)).inverse()*(UC_b/n+2.0*UP_b/n/(n-1));
}

// [[Rcpp::export]]
List Para_TI(Eigen::MatrixXd Z,
             Eigen::MatrixXd IndD,
             Eigen::MatrixXd IndRL,
             Eigen::MatrixXd IndRA,
             Eigen::MatrixXd IndA,
             Eigen::VectorXd b,
             Eigen::VectorXd h,
             int K = 2000,
             double tol=0.001){
  const int n(Z.rows()),m(h.size()), p(b.size());
  int k(0);
  double diff(99);
  Eigen::MatrixXd EWmat(n,m);
  Eigen::VectorXd b_hat = b, h_hat = h, b_new, h_new, Diff(p + m);
  while(diff > tol and k < K){
    EWmat = EWfun(Z, IndD,IndRL,b_hat, h_hat);
    h_new = Lambda(Z, EWmat, IndA,IndRA, b_hat, h_hat);
    b_new = b_hat + Beta(Z, EWmat, IndA, IndRA, b_hat, h_new);
    Diff  << (b_new - b_hat),
             (h_new - h_hat);
    diff  = Diff.cwiseAbs().sum();
    b_hat = b_new;
    h_hat = h_new;
    k++;
  }
  return List::create(Named("b.hat") = b_hat,
                      Named("h.hat") = h_hat,
                      Named("iter") = k);
}


//[[Rcpp::export]]
Eigen::MatrixXd EWfun_CL(Eigen::MatrixXd Z,
                  Eigen::MatrixXd IndD,
                  Eigen::MatrixXd IndRL,
                  Eigen::VectorXd b,
                  Eigen::VectorXd h){
  const int n(Z.rows()), m(h.size());
  double bot;
  Eigen::VectorXd ebz(n);
  Eigen::MatrixXd EW(n,m);
  ebz = (Z * b).array().exp();
  for(int i = 0; i < n; ++i){
    EW.row(i) = (IndRL.row(i)).adjoint().array()*h.array()*ebz(i) ;
    bot = 1-exp(-h.dot(IndRL.row(i))*ebz(i));
    if(bot==0.0){bot=1.0;}
    EW.row(i) = EW.row(i)/bot+IndD.row(i);
  }
  return EW;
}

//[[Rcpp::export]]
Eigen::VectorXd Lambda_CL(Eigen::MatrixXd Z,
                          Eigen::MatrixXd EW,
                          Eigen::MatrixXd IndA,
                          Eigen::MatrixXd IndRA,
                          Eigen::VectorXd b,
                          Eigen::VectorXd h){
  const int n(Z.rows()), m(h.size());
  double Rij;
  Eigen::VectorXd  UC_Lambda1(m),UC_Lambda2(m),UP_Lambda(m), Ind2ij(m), ebz(n);
  UC_Lambda1.fill(0);UC_Lambda2.fill(0);UP_Lambda.fill(0);
  ebz = (Z * b).array().exp();
  UC_Lambda1 = (IndRA.cwiseProduct(EW)).colwise().sum();
  for(int i = 0; i < n; ++i){
    UC_Lambda2 += ebz(i) * IndRA.row(i);
  }
  return (UC_Lambda1).array()/(UC_Lambda2).array();
}

//[[Rcpp::export]]
Eigen::MatrixXd Beta_CL(Eigen::MatrixXd Z,
                        Eigen::MatrixXd EW,
                        Eigen::MatrixXd IndA,
                        Eigen::MatrixXd IndRA,
                        Eigen::VectorXd b,
                        Eigen::VectorXd h){
  const int n(Z.rows()),p(b.size());
  Eigen::VectorXd UC_b(p), ebz(n);
  UC_b.fill(0);
  Eigen::MatrixXd JC_b(p,p);
  JC_b.fill(0);
  ebz = (Z*b).array().exp();
  for(int i=0; i<n; i++){
    UC_b += ((IndRA.row(i)).dot(EW.row(i)) - h.dot(IndRA.row(i))*ebz(i)) *Z.row(i);
    JC_b += h.dot(IndRA.row(i))*ebz(i)*(Z.row(i).adjoint()*Z.row(i));
  }
  return   (JC_b/n).inverse()*(UC_b/n);
}

// [[Rcpp::export]]
List Para_TI_CL(Eigen::MatrixXd Z,
                Eigen::MatrixXd IndD,
                Eigen::MatrixXd IndRL,
                Eigen::MatrixXd IndRA,
                Eigen::MatrixXd IndA,
                Eigen::VectorXd b,
                Eigen::VectorXd h,
                int K = 2000,
                double tol=0.001){
  const int n(Z.rows()),m(h.size()), p(b.size());
  int k(0);
  double diff(99);
  Eigen::MatrixXd EWmat(n,m);
  Eigen::VectorXd b_hat = b, h_hat = h, b_new, h_new, Diff(p + m);
  while(diff > tol and k < K){
    EWmat = EWfun(Z, IndD,IndRL,b_hat, h_hat);
    h_new = Lambda_CL(Z, EWmat, IndA,IndRA, b_hat, h_hat);
    b_new = b_hat + Beta_CL(Z, EWmat, IndA, IndRA, b_hat, h_new);
    Diff  << (b_new - b_hat),
             (h_new - h_hat);
    diff  = Diff.cwiseAbs().sum();
    b_hat = b_new;
    h_hat = h_new;
    k++;
  }
  return List::create(Named("b.hat") = b_hat,
                      Named("h.hat") = h_hat,
                      Named("iter") = k);
}

