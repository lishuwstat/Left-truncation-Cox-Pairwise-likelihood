LTsurv <-function(truncation, time, time2=rep(0,length(time)) , delta, type, Z,
                time_points = quantile(unique(sort(c(time,time2,truncation)))[-1],seq(0.1,1,0.1)),
                boot.num=50){
  # truncation: the truncated time
  # time: For right censored data, this is the follow up time.
  #       For interval data, the "time" argument is the starting time for the interval.
  # time2:Ending time of the interval for interval censored data only.
  #       Intervals are assumed to be open on the left and closed on the right, (start, end].
  # delta:For right censored data, 0="censored", 1="observed".
  #       For interval censored data, 1="left censored", 2="interval censored", 3="right censored".
  #       For partly interval censored data, 0 ="observed", 1="left censored", 2="interval censored", 3="right censored".
  # type: character string specifying the type of censoring. Possible values are "right", "interval", "partly interval".
  # time_points: The cumulative baseline hazard function at which time to be estimated,
  #       the default value of time_points means estimate the cumulative baseline hzard at the
  #       quantile of distinct time.

  if (missing(truncation)){
    stop("Must have a truncation argument")
  }
  if (missing(time)){
    stop("Must have a time argument")
  }
  if (missing(delta)){
    stop("Must have a delta argument")
  }
  if (missing(type)){
    stop("Must have a type argument")
  }
  if((type=="interval"|type=="partly interval") & missing(time2)){
    stop("Interval Censored data must have a time2 argument")
  }

  if(missing(time2)){
    if( (length(truncation)!=length(time)) |(length(truncation)!=length(delta))
        |(length(time)!=length(delta)) ){
      stop("Lengths of truncation, time, time2 and delta must be equal ")
    }
  }else{
    if( (length(truncation)!=length(time)) | (length(truncation)!=length(time2))
        |(length(truncation)!=length(delta)) | (length(time)!=length(time2))
        |(length(time)!=length(delta)) |(length(time)!=length(time2))){
      stop("Lengths of truncation, time, time2 and delta must be equal ")
    }
  }
  if(missing(time2)| type=="right"){
    dl=cbind(delta,0,0,1-delta);dl
    OALRmat=cbind(time*dl[,1], truncation, time*(1-dl[,1]), time)
  }

  if(type=="interval"|type=="partly interval"){
    dl=1*cbind(delta==0,delta==1,delta==2,delta==3)
    OALRmat=cbind(time*dl[,1], truncation,  truncation*dl[,2]+time*dl[,3]+time*dl[,4],
                  time*dl[,1]+time2*dl[,2]+time2*dl[,3]+time*dl[,4] )
  }

  nsam=length(time)
  sumstats  = colMeans(dl)

  names(sumstats) = c("Exact Observation", "Left-Censored", "Interval-Censored",  "Right-Censored")
  ## Need to comfirmed with Li, and try to get dl from OALRmat
  if(type=="right"){
    sumstats=sumstats[c(1,4)]
  }else if(type=="interval"){
    sumstats=sumstats[-1]
  }

  order.LR  = unique(sort(OALRmat))[-1]
  IND.LR    = RLInd(OALRmat,order.LR,dl[,2]+dl[,3])
  Ind.D     = DInd(OALRmat,order.LR)
  Ind.RA    = RAInd(OALRmat,order.LR)
  Ind.A     = AInd(OALRmat,order.LR)
  Mn        = length(order.LR)
  p         = dim(Z)[2]
  beta.ini  = rep(0,p)
  lamb.ini  = rep(1/Mn,Mn)

  max.loops =2000; tol=10^(-3)
  res       = Para_TI(Z=Z, IndD = Ind.D, IndRL = IND.LR,  Ind.RA, Ind.A, beta.ini, lamb.ini,  max.loops, tol)

  f.final = 1*(matrix(rep(order.LR,each=length(time_points)), nrow = length(time_points))
               <= matrix(time_points, nrow = length(time_points), ncol = length(order.LR)))%*%res$h.hat

  if(is.null(colnames(Z))){
     names(res$b.hat) = paste("Z",1:dim(Z)[2],sep="")
  }else{names(res$b.hat)=colnames(Z)}

  if(is.null(names(time_points))){rownames(f.final)=time_points
  }else{rownames(f.final)= names(time_points)}

  set.seed(1)
  B=boot.num;
  beta.boot = matrix(NA, nrow = B, ncol = p)
  f.boot    = matrix(NA, nrow = B, ncol = length(time_points))
  for(b in 1:B){
   # print(b)
    Ind.boot    = sample(1:nsam,nsam,replace = T)
    Z.b         = Z[Ind.boot,]
    dl.b        = dl[Ind.boot,]
    OALRmat.b   = OALRmat[Ind.boot,]
    order.LR.b  = unique(sort(OALRmat.b))[-1]

    # (type=="right"){
    #   IND.LR.b    = RLInd(OALRmat.b,order.LR.b,dl.b[,2]+dl.b[,3])
    # }
    # if((type=="interval")||(type=="partly interval")){
    IND.LR.b    = RLInd(OALRmat.b,order.LR.b,dl.b[,2]+dl.b[,3])
    # }
    IND.LR.b    = RLInd(OALRmat.b,order.LR.b,dl.b[,2]+dl.b[,3])
    Ind.D.b     =  DInd(OALRmat.b,order.LR.b)
    Ind.RA.b    = RAInd(OALRmat.b,order.LR.b)
    Ind.A.b     =  AInd(OALRmat.b,order.LR.b)
    Mn.b        = length(order.LR.b)
    lamb.ini.b  = rep(1/Mn.b,Mn.b)
    bb          = Para_TI(Z.b, Ind.D.b, IND.LR.b, Ind.RA.b, Ind.A.b, beta.ini, lamb.ini.b, max.loops,tol)
    beta.boot[b,] = bb$b.hat
    f.boot[b,] = 1*(matrix(rep(order.LR.b,each=length(time_points)), nrow = length(time_points))
                    <=matrix(time_points, nrow = length(time_points), ncol = length(order.LR.b)))%*%bb$h.hat

  }
  see.b=apply(beta.boot, 2, sd)
  see.f=apply(f.boot, 2, sd)


  results    = list(Coefficients = res$b.hat,
                    BaselineHazard = res$h.hat,
                    Cumulative =f.final,
                    sdCoefficients = see.b,
                    sdCumulative = see.f,
                    sumstats=sumstats,
                    order.LR=order.LR
  )
  class(results) = c("LTsurv", "list")
  return(results)
}
