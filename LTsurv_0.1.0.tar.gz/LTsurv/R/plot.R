

plot.LTsurv<- function(x,type="hazard"){
  # x: a LTsurv object, generally produced by LTsurv function
  # type: if type="hazard", print the plot of cumulative baseline hazard function
  #       if type="survival", print the plot of baseline survival funciton
  if(!inherits(x,"LTsurv"))
    stop("Object must be of class 'LTsurv' !")

  if(missing(type)|type=="hazard"){
      plot(x$order.LR,cumsum(x$BaselineHazard),type="l",ylab="",
       xlab="time", main="Cummulative baseline hazard")
  }
  if(type=="survival"){
    plot(x$order.LR,exp(-cumsum(x$BaselineHazard)),type="l",ylab="",
         xlab="time", main="Baseline Survival")
  }
  }


