#' A Package for Computating the Pairwise Likelihood Augmented Proportional Hazards Model Estimator for Left-Truncated Failure Time Data.
#'
#' This package provides both lower-level \code{C++} functions (\code{Para_TI()}, \code{PLAC_TI_CL()} and an R wrapper function \code{Para()} to calculate the Pairwise Likelihood Augmented Proportional Hazards Model Estimator for Left-Truncated Failure Time Data as proposed by Shao, Li and Li. (2022).
#'
#' @section Wrapper Function \code{Para()}:
#' This \code{R} wrapper function calls different \code{C++} function depending on the covariate types \code{data} has.
#'
#' @section C++ Functions:
#' The three \code{C++} functions \code{PLAC_TI()}, \code{PLAC_TV()} and \code{PLAC_TvR()} provide a direct interface to the algorithm in case that users need to supply more flexible time-dependent coavriates other than indicator functions.
#'
#' @references Shao. L, Li. H, Li S. (2022) "A General Pairwise Pseudo-likelihood Estimation Approach for the Proportional Hazards Model with Left-Truncated Failure Time Data." (Submitted to \emph{XXX }.)
#' @docType package
#' @name Para-package
NULL
#> NULL
