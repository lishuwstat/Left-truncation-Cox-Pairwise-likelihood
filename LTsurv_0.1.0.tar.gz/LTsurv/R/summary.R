

summary.LTsurv <- function(x){
  if(!inherits(x,"LTsurv"))
    stop("Object must be of class 'LTsurv' !")

  cat("Proportions \n")
  print(x$sumstats)
  cat("\n\n")


  coe = x$Coefficients
  coeStd = x$sdCoefficients
  zvalue =  coe/coeStd
  pvalue <- 2*(1-pnorm(abs(zvalue),0,1))
  CoeTab = data.frame(cbind(coe,coeStd,zvalue,pvalue))

  CoeTab$stars=""
  CoeTab$stars[CoeTab$pvalue <   .1] <- "."
  CoeTab$stars[CoeTab$pvalue <  .05] <- "*"
  CoeTab$stars[CoeTab$pvalue <  .01] <- "**"
  CoeTab$stars[CoeTab$pvalue < .001] <- "***"
  colnames(CoeTab)=c("Estimate","Std.Error","z value","Pr(>|z|)","")

  cat("Coefficients: \n")
  print(CoeTab)
  cat("---\nSignif. codes: 0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1\n\n\n")

}


